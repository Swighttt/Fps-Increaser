# Fps increaser — Fabric 1.21.11

A starter client-side mod project for XREAM, using a red + cyan settings screen.

## Features in this source starter
- Aim Assist toggle (default: G)
- Settings screen (default: Right Shift)
- Range setting (2–12 blocks)
- Aim strength setting
- Target toggles for players and mobs
- Red/cyan themed settings panel

## Build
1. Install a Java 21 JDK.
2. Install Gradle, or add the Gradle wrapper using a compatible Gradle installation.
3. Open this folder as a Gradle project and run `gradle build`.
4. The jar should appear in `build/libs/`.

## Important
- This is source code, not a prebuilt/verified `.jar`.
- Minecraft/Fabric mappings and dependency versions can change; if Gradle reports a version-resolution or API error, update the versions in `gradle.properties` to versions published for Fabric 1.21.11.
- Aim assistance changes the local camera direction and does not automate attacks.
- Use only where the server rules permit client-side assistance.
