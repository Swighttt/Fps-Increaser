package xream.fpsincreaser;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class FpsIncreaserClient implements ClientModInitializer {
    private static KeyBinding openSettingsKey;
    private static KeyBinding toggleAimKey;

    private static boolean aimEnabled = false;
    private static double aimRange = 5.0;
    private static double aimStrength = 0.18;
    private static boolean targetPlayers = true;
    private static boolean targetMobs = true;

    @Override
    public void onInitializeClient() {
        openSettingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fps_increaser.open_settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));
        toggleAimKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fps_increaser.toggle_aim",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleAimKey.wasPressed()) {
                aimEnabled = !aimEnabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("§cFps increaser §8» §bAim Assist: " +
                            (aimEnabled ? "§aON" : "§cOFF")), true);
                }
            }
            while (openSettingsKey.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new SettingsScreen());
                }
            }
            if (aimEnabled) {
                tickAimAssist(client);
            }
        });
    }

    private static void tickAimAssist(MinecraftClient client) {
        if (client.player == null || client.world == null || client.currentScreen != null) return;
        LivingEntity target = findTarget(client);
        if (target == null) return;

        Vec3d eyes = client.player.getEyePos();
        Vec3d targetPos = target.getBoundingBox().getCenter();
        double dx = targetPos.x - eyes.x;
        double dy = targetPos.y - eyes.y;
        double dz = targetPos.z - eyes.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        float targetPitch = (float) (-(MathHelper.atan2(dy, horizontal) * (180.0 / Math.PI)));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - client.player.getYaw());
        float pitchDelta = MathHelper.wrapDegrees(targetPitch - client.player.getPitch());

        // Gentle, configurable camera correction. It does not attack or click automatically.
        client.player.setYaw(client.player.getYaw() + yawDelta * (float) aimStrength);
        client.player.setPitch(MathHelper.clamp(
                client.player.getPitch() + pitchDelta * (float) aimStrength, -90.0F, 90.0F));
    }

    private static LivingEntity findTarget(MinecraftClient client) {
        LivingEntity best = null;
        double bestDistance = aimRange;
        for (Entity entity : client.world.getEntities()) {
            if (!(entity instanceof LivingEntity living) || entity == client.player || !living.isAlive()) continue;
            if (living.isSpectator()) continue;

            boolean isPlayer = living instanceof PlayerEntity;
            if (isPlayer && !targetPlayers) continue;
            if (!isPlayer && !targetMobs) continue;

            double distance = client.player.distanceTo(living);
            if (distance > bestDistance) continue;

            // Only assist toward entities reasonably close to the centre of the screen.
            Vec3d look = client.player.getRotationVec(1.0F).normalize();
            Vec3d direction = living.getBoundingBox().getCenter().subtract(client.player.getEyePos()).normalize();
            double dot = look.dotProduct(direction);
            if (dot < 0.72) continue;

            bestDistance = distance;
            best = living;
        }
        return best;
    }

    static boolean isAimEnabled() { return aimEnabled; }
    static void setAimEnabled(boolean value) { aimEnabled = value; }
    static double getAimRange() { return aimRange; }
    static void setAimRange(double value) { aimRange = MathHelper.clamp(value, 2.0, 12.0); }
    static double getAimStrength() { return aimStrength; }
    static void setAimStrength(double value) { aimStrength = MathHelper.clamp(value, 0.05, 0.50); }
    static boolean targetsPlayers() { return targetPlayers; }
    static void setTargetPlayers(boolean value) { targetPlayers = value; }
    static boolean targetsMobs() { return targetMobs; }
    static void setTargetMobs(boolean value) { targetMobs = value; }
}
