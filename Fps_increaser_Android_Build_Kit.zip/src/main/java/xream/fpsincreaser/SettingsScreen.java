package xream.fpsincreaser;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class SettingsScreen extends Screen {
    private int page = 0;

    public SettingsScreen() {
        super(Text.literal("Fps increaser"));
    }

    @Override
    protected void init() {
        clearChildren();
        int cx = width / 2;
        int y = height / 2 - 72;

        addDrawableChild(ButtonWidget.builder(aimText(), b -> {
            FpsIncreaserClient.setAimEnabled(!FpsIncreaserClient.isAimEnabled());
            b.setMessage(aimText());
        }).dimensions(cx - 100, y, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(rangeText(), b -> {
            double next = FpsIncreaserClient.getAimRange() + 1.0;
            if (next > 12.0) next = 2.0;
            FpsIncreaserClient.setAimRange(next);
            b.setMessage(rangeText());
        }).dimensions(cx - 100, y + 25, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(strengthText(), b -> {
            double next = FpsIncreaserClient.getAimStrength() + 0.05;
            if (next > 0.50) next = 0.05;
            FpsIncreaserClient.setAimStrength(next);
            b.setMessage(strengthText());
        }).dimensions(cx - 100, y + 50, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(playersText(), b -> {
            FpsIncreaserClient.setTargetPlayers(!FpsIncreaserClient.targetsPlayers());
            b.setMessage(playersText());
        }).dimensions(cx - 100, y + 75, 98, 20).build());

        addDrawableChild(ButtonWidget.builder(mobsText(), b -> {
            FpsIncreaserClient.setTargetMobs(!FpsIncreaserClient.targetsMobs());
            b.setMessage(mobsText());
        }).dimensions(cx + 2, y + 75, 98, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx - 100, y + 103, 200, 20).build());
    }

    private Text aimText() {
        return Text.literal("Aim Assist: " + (FpsIncreaserClient.isAimEnabled() ? "ON" : "OFF"));
    }
    private Text rangeText() {
        return Text.literal(String.format("Aim Range: %.0f blocks (click)", FpsIncreaserClient.getAimRange()));
    }
    private Text strengthText() {
        return Text.literal(String.format("Aim Strength: %.2f (click)", FpsIncreaserClient.getAimStrength()));
    }
    private Text playersText() {
        return Text.literal("Players: " + (FpsIncreaserClient.targetsPlayers() ? "ON" : "OFF"));
    }
    private Text mobsText() {
        return Text.literal("Mobs: " + (FpsIncreaserClient.targetsMobs() ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(width / 2 - 116, height / 2 - 105, width / 2 + 116, height / 2 + 147, 0xE51A1018);
        context.fill(width / 2 - 116, height / 2 - 105, width / 2 + 116, height / 2 - 102, 0xFFFF3038);
        context.fill(width / 2 - 116, height / 2 - 102, width / 2 - 113, height / 2 + 147, 0xFF22DDEE);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("XREAM  •  FPS INCREASER"), width / 2, height / 2 - 94, 0xFF22DDEE);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
